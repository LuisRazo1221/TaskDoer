import { Component } from '@angular/core';

import * as firebase from 'firebase/app';
import {firebaseConfig} from 'src/firebase.config';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls:['app.componenet.scss']
})
export class AppComponent {
  constructor() {}

  initializeApp(){
    firebase.initializeApp(firebaseConfig)
  }
}