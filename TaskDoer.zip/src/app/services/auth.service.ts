import { Injectable } from '@angular/core';
import {
  Auth,
  signInWithEmailandPassword,
  createUserWithEmailandPassword,
  signOut
  sendPasswordResetEmail
} from '@angular/fire/auth'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private auth:Auth) { }

  async loginUser(email:string, password:string){
    try{
      const user= await signInWithEmailandPassword(this.auth, email, password)
    } catch(e){
      return null
    }
  }

  async signUpUsec(email:string, password:string){
    try{
      const user= await signInWithEmailandPassword(this.auth, email, password)
    } catch(e){
      return null
    }
  }

  async resetPassword(email:string){
    try{
      const user= await sendPasswordResetEmail(this.auth, email)
    } catch(e){
      return null
    }
  }

  logOutUser(){
    return signOut(this.auth)
  }
}