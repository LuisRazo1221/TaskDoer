import { Injectable } from '@angular/core';

import { 
  Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail
 } from '@angular/fire/auth';


 @Injectable({
    providedIn: 'root'
 })
 export class AuthService {

    constructor(private auth: Auth){}

    async loginUser (email: string, password: string){
      try {
        const user = await signInWithEmailAndPassword(this.auth, email, password);
        return user;
      } catch (e) {
        return null;
      }
    }

    async signUpUser (email: string, password: string){
      try {
        const user = await createUserWithEmailAndPassword(this.auth, email, password);
        return user;
      } catch (e) {
        return null;
      }
    }

    async resetPassword (email: string){
      try {
        const user = await sendPasswordResetEmail(this.auth, email);
        return user;
      } catch (e) {
        return null;
      }
    }

    logOutUser(){
      return signOut(this.auth)
    }
 }