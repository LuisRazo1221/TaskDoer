export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyA12-O43a8WaaAyyuhmyWTuEDQnBGcNy-A",
        authDomain: "taskdoer2.firebaseapp.com",
        projectId: "taskdoer2",
        storageBucket: "taskdoer2.appspot.com",
        messagingSenderId: "622246622270",
        appId: "1:622246622270:web:d09e9eb52b9703db0c8d6f"
    }
};